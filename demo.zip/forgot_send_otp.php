<?php
session_start();
include('connection.php');
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'src/PHPMailer.php';
require 'src/SMTP.php';
require 'src/Exception.php';

if(isset($_POST['email'])){
    $email = trim($_POST['email']);

    // Check if email exists
    $stmt = $con->prepare("SELECT id FROM tbl_members WHERE email=?");
    $stmt->bind_param("s",$email);
    $stmt->execute();
    $result = $stmt->get_result();
    if($result->num_rows==0){ echo "Email not registered!"; exit; }

    $otp = rand(100000,999999);
    $_SESSION['fp_otp'] = $otp;
    $_SESSION['fp_email'] = $email;
    $_SESSION['fp_otp_expiry'] = time()+300;

    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'ady10112004@gmail.com';
        $mail->Password   = 'loky dacf vmdi hwvi';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;

        $mail->setFrom('ady10112004@gmail.com','Sadhu Vandana');
        $mail->addAddress($email);

        $mail->isHTML(true);
        $mail->Subject = 'Password Reset OTP';
        $mail->Body    = "Your OTP for password reset is <b>$otp</b>. Valid for 5 minutes.";

        if($mail->send()){ echo "sent"; }
        else{ echo "Failed to send OTP"; }
    } catch(Exception $e){ echo "Mailer Error: ".$mail->ErrorInfo; }
}
?>
