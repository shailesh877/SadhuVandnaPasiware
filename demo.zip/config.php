<?php
$razorpay_config = array(
'api_key' => 'rzp_test_RMXAUXty6nvaXm',
'api_secret' => 'It60ovNrbtNA6kPw0kxET8Fl',
);
?>