<?php
$con=mysqli_connect("localhost","u941015828_demo","Demohsdj536178^&$#%^","u941015828_demo");
?>