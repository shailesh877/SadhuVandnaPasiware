<?php
session_start();
include("../connection.php");

if (!isset($_SESSION['admin_id'])) {

    // Check If Cookie Exists
    if (isset($_COOKIE['sadhu_admin_id']) && isset($_COOKIE['sadhu_admin_token'])) {

        $id = $_COOKIE['sadhu_admin_id'];
        $token = $_COOKIE['sadhu_admin_token'];

        $q = mysqli_query($con, "SELECT * FROM tbl_admin WHERE admin_id='$id' LIMIT 1");

        if (mysqli_num_rows($q) == 1) {
            $row = mysqli_fetch_assoc($q);

            // Verify Cookie Token
            if (sha1($row['password']) === $token) {

                // Auto-Login using Cookie
                $_SESSION['admin_id'] = $row['admin_id'];
                $_SESSION['admin_name'] = $row['username'];

            }
        }
    }
}

// Still not logged in → redirect to login
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login");
    exit;
}


// ------------ Fetch News Using ID -------------
if (!isset($_GET['id'])) {
    die("Invalid Request");
}
$id = intval($_GET['id']);

$query = mysqli_query($con, "SELECT * FROM tbl_news WHERE id='$id'");
$data = mysqli_fetch_assoc($query);

if (!$data) {
    die("News not found");
}

// ------------ Update News ---------------------
if (isset($_POST['update'])) {

    date_default_timezone_set("Asia/Kolkata");

    $title = mysqli_real_escape_string($con, $_POST['title']);
    $description = mysqli_real_escape_string($con, $_POST['description']);
    $date = $_POST['date'];

    $final_image = $data['image']; // default old image

    // ---- If New Image Selected ----
    if (!empty($_FILES['image']['name'])) {

        $img_name = time() . "_" . $_FILES['image']['name'];
        $tmp = $_FILES['image']['tmp_name'];
        $upload_path = "../uploads/news/" . $img_name;

        if (move_uploaded_file($tmp, $upload_path)) {
            // delete old image
            if (file_exists("../uploads/news/" . $data['image'])) {
                unlink("../uploads/news/" . $data['image']);
            }
            $final_image = $img_name;
        }
    }

    // ---- Update Query ----
    $update = mysqli_query($con,
        "UPDATE tbl_news SET 
            title='$title',
            description='$description',
            created_at='$date',
            image='$final_image'
        WHERE id='$id'"
    );

    if ($update) {
        echo "<script>
                alert('News Updated Successfully!');
                window.location='add_views_news.php';
              </script>";
    } else {
        echo "<script>alert('Error while updating news');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1.0" />
  <title>Edit News - Admin Panel</title>
  <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
</head>

<body class="bg-gradient-to-br from-orange-50 to-orange-100 min-h-screen">
  
<!-- Header -->
<header class="bg-white shadow-md sticky top-0 z-40">
    <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-2 flex items-center">
        <a href="add_views_news.php"
          class="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center hover:bg-orange-200 transition mr-2">
          <i class="fa-solid fa-arrow-left text-orange-600"></i>
        </a>
        <h1 class="text-xl font-bold text-orange-600 flex-1 text-center">Edit News</h1>
    </div>
</header>

<!-- MAIN -->
<main class="flex-1 flex justify-center items-center py-4">
  <div class="bg-white rounded-xl shadow-lg p-8 max-w-xl w-full">

    <form method="POST" enctype="multipart/form-data">

      <div class="grid grid-cols-1 md:grid-cols-2 gap-6">

        <!-- Image -->
        <div class="md:col-span-2">
          <label class="block text-sm font-medium text-gray-700 mb-2">News Image</label>

          <div class="flex items-center gap-4">
            <div class="w-28 h-28 bg-gray-100 rounded-lg border-2 border-dashed border-gray-300 flex items-center justify-center overflow-hidden">
              <img id="preview" src="../uploads/news/<?= $data['image'] ?>" class="object-cover w-full h-full rounded-lg">
            </div>

            <div class="flex-1">
              <input type="file" name="image" accept="image/*" onchange="showPreview(event)"
                class="w-full px-4 py-2 border border-gray-300 rounded-lg text-sm"/>
              <p class="text-xs text-gray-500 mt-2">Upload new image (JPG, PNG - Max 2MB)</p>
            </div>
          </div>
        </div>

        <!-- Title -->
        <div class="md:col-span-2">
          <label class="block text-sm font-medium text-gray-700 mb-2">News Title *</label>
          <input type="text" name="title" required
            value="<?= $data['title'] ?>"
            class="w-full px-4 py-3 border text-base border-gray-300 rounded-lg"/>
        </div>

        <!-- Description -->
        <div class="md:col-span-2">
          <label class="block text-sm font-medium text-gray-700 mb-2">Description *</label>
          <textarea name="description" required rows="5"
            class="w-full px-4 py-3 text-base border border-gray-300 rounded-lg"><?= $data['description'] ?></textarea>
        </div>

        <!-- Date -->
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">Date *</label>
          <input type="date" name="date" required
            value="<?= date('Y-m-d', strtotime($data['created_at'])) ?>"
            class="w-full px-4 py-3 text-base border border-gray-300 rounded-lg"/>
        </div>

        <!-- Buttons -->
        <div class="md:col-span-2 flex gap-4 mt-4">
          <button type="submit" name="update"
            class="px-8 py-3 text-sm bg-orange-500 hover:bg-orange-600 text-white rounded-lg shadow flex items-center gap-2">
            <i class="fa-solid fa-check"></i> Update News
          </button>

          <a href="add_views_news.php"
            class="px-8 py-3 text-sm bg-gray-200 hover:bg-gray-300 text-gray-700 rounded-lg flex items-center gap-2">
            <i class="fa-solid fa-xmark"></i> Cancel
          </a>
        </div>

      </div>
    </form>
  </div>
</main>

<script>
function showPreview(event){
    document.getElementById('preview').src = URL.createObjectURL(event.target.files[0]);
}
</script>

</body>
</html>
