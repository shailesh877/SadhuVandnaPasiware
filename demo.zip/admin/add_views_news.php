<?php
session_start();
include("../connection.php");

if (!isset($_SESSION['admin_id'])) {

    // Check If Cookie Exists
    if (isset($_COOKIE['sadhu_admin_id']) && isset($_COOKIE['sadhu_admin_token'])) {

        $id = $_COOKIE['sadhu_admin_id'];
        $token = $_COOKIE['sadhu_admin_token'];

        $q = mysqli_query($con, "SELECT * FROM tbl_admin WHERE admin_id='$id' LIMIT 1");

        if (mysqli_num_rows($q) == 1) {
            $row = mysqli_fetch_assoc($q);

            // Verify Cookie Token
            if (sha1($row['password']) === $token) {

                // Auto-Login using Cookie
                $_SESSION['admin_id'] = $row['admin_id'];
                $_SESSION['admin_name'] = $row['username'];

            }
        }
    }
}

// Still not logged in → redirect to login
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login");
    exit;
}

date_default_timezone_set("Asia/Kolkata");

$message = "";

/* -----------------------------
   INSERT NEWS
------------------------------ */
if(isset($_POST["submit_news"])){

    $title = mysqli_real_escape_string($con, $_POST["title"]);
    $description = mysqli_real_escape_string($con, $_POST["description"]);

    // Image upload
    $image_name = "";
    if(!empty($_FILES["image"]["name"])){

        $image_name = time() . "_" . basename($_FILES["image"]["name"]);
        $target_path = "../uploads/news/";

        if(!is_dir($target_path)){
            mkdir($target_path, 0777, true);
        }

        $full_path = $target_path . $image_name;
        move_uploaded_file($_FILES["image"]["tmp_name"], $full_path);
    }

    $date = date("Y-m-d H:i:s");

    $sql = "INSERT INTO tbl_news (title, description, image, created_at)
            VALUES ('$title', '$description', '$image_name', '$date')";

    if(mysqli_query($con, $sql)){
        $message = "<p class='text-green-600 font-semibold'>News Added Successfully!</p>";
    } else {
        $message = "<p class='text-red-600 font-semibold'>ERROR!</p>";
    }
}

/* -----------------------------
   DELETE NEWS
------------------------------ */
if(isset($_GET["delete"])){
    $del_id = $_GET["delete"];

    // delete image
    $img = mysqli_fetch_assoc(mysqli_query($con, "SELECT image FROM tbl_news WHERE id='$del_id'"));
    if($img && $img["image"]){
        $path = "../uploads/news/" . $img["image"];
        if(file_exists($path)){ unlink($path); }
    }

    mysqli_query($con, "DELETE FROM tbl_news WHERE id='$del_id'");
    echo "<script>window.location='add_views_news.php';</script>";
}

/* -----------------------------
   FETCH ALL NEWS
------------------------------ */
$fetch_news = mysqli_query($con, "SELECT * FROM tbl_news ORDER BY id DESC");

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1.0" />
  <title>Sadhu Vandana - News Management</title>

  <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />

  <style>
    .truncate-line {
      display: -webkit-box !important;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .overflow-y-auto::-webkit-scrollbar {
      width: 0px;
      display: none;
    }
  </style>

  <script>
    function toggleDescription(id, btn){
      const p = document.getElementById(id);
      if(p.classList.contains("truncate-line")){
        p.classList.remove("truncate-line");
        btn.textContent = "see less";
      } else {
        p.classList.add("truncate-line");
        btn.textContent = "see more";
      }
    }

    // IMAGE PREVIEW
    function previewImage(event){
      const reader = new FileReader();
      reader.onload = function(){
        document.getElementById("previewBox").innerHTML = 
          `<img src="${reader.result}" class="w-full h-full object-cover rounded-lg">`;
      }
      reader.readAsDataURL(event.target.files[0]);
    }
  </script>

</head>

<body class="bg-gradient-to-br from-orange-50 to-orange-100 min-h-screen">

  <!-- Header -->
  <header class="bg-white shadow-md sticky top-0 z-40">
    <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-2 flex items-center">
      <a href="index"
        class="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center hover:bg-orange-200 transition mr-2">
        <i class="fa-solid fa-arrow-left text-orange-600"></i>
      </a>
      <h1 class="text-xl font-bold text-orange-600 flex-1 text-center">News Management</h1>
    </div>
  </header>

  <!-- Main Content -->
  <main class="max-w-8xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex flex-col md:flex-row gap-8">

    <!-- Right: ADD NEWS -->
    <div class="w-full md:max-w-md md:w-1/3 md:order-2">

      <div class="bg-white rounded-xl shadow-lg p-6 mb-4">

        <?= $message ?>

        <div class="flex items-center gap-2 mb-6">
          <div class="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
            <i class="fa-solid fa-plus text-orange-600 text-lg"></i>
          </div>
          <h2 class="text-xl font-bold text-gray-800">Add New News</h2>
        </div>

        <form method="POST" enctype="multipart/form-data">

          <div class="grid grid-cols-1 md:grid-cols-2 gap-6">

            <!-- Image Upload -->
            <div class="md:col-span-2">
              <label class="block text-sm font-medium text-gray-700 mb-2">News Image</label>

              <div class="flex items-center gap-4">
                <div id="previewBox"
                     class="w-32 h-32 bg-gray-100 rounded-lg border-2 border-dashed border-gray-300 flex items-center justify-center overflow-hidden">
                    <i class="fa-solid fa-image text-gray-400 text-3xl"></i>
                </div>

                <div class="flex-1">
                  <input type="file" name="image" onchange="previewImage(event)" required
                         accept="image/*"
                         class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 outline-none transition"/>
                </div>
              </div>
            </div>

            <!-- Title -->
            <div class="md:col-span-2">
              <label class="block text-sm font-medium text-gray-700 mb-2">News Title *</label>
              <input type="text" name="title" required
                     placeholder="Enter news title"
                     class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500"/>
            </div>

            <!-- Description -->
            <div class="md:col-span-2">
              <label class="block text-sm font-medium text-gray-700 mb-2">Description *</label>
              <textarea name="description" required rows="5"
                        class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 resize-none"
                        placeholder="Enter news description"></textarea>
            </div>
          </div>

          <div class="flex gap-3 mt-6">
            <button name="submit_news" type="submit"
              class="px-6 py-2.5 bg-orange-500 hover:bg-orange-600 text-white rounded-lg shadow flex items-center gap-2">
              <i class="fa-solid fa-check"></i> Submit News
            </button>

            <button type="reset"
              class="px-6 py-2.5 bg-gray-200 hover:bg-gray-300 text-gray-700 rounded-lg font-medium">
              <i class="fa-solid fa-rotate-right mr-1"></i> Reset
            </button>
          </div>

        </form>
      </div>
    </div>


    <!-- Left: NEWS LIST -->
    <div class="w-full md:w-2/3 md:order-1">

      <div class="bg-white rounded-xl shadow-lg p-6">

        <h2 class="text-xl font-bold text-gray-800 mb-6">All News</h2>

        <div class="hidden md:block overflow-y-auto h-[525px]">

          <table class="w-full">
            <thead class="bg-gradient-to-r from-orange-500 to-orange-600 text-white sticky top-0">
              <tr>
                <th class="px-6 py-4 text-left text-sm">ID</th>
                <th class="px-6 py-4 text-left text-sm">Image</th>
                <th class="px-6 py-4 text-left text-sm">Title</th>
                <th class="px-6 py-4 text-left text-sm">Description</th>
                <th class="px-6 py-4 text-left text-sm">Date</th>
                <th class="px-6 py-4 text-center text-sm">Actions</th>
              </tr>
            </thead>

            <tbody class="divide-y divide-gray-200">
              <?php
              $i = 1;
              while($row = mysqli_fetch_assoc($fetch_news)){
              ?>
              <tr class="hover:bg-orange-50 transition">
                <td class="px-6 py-4 text-sm font-medium text-gray-700">#<?= $row["id"] ?></td>

                <td class="px-6 py-4">
                  <img src="../uploads/news/<?= $row["image"] ?>"
                       class="w-14 h-14 rounded-lg object-cover">
                </td>

                <td class="px-6 py-4 text-sm text-gray-800">
                  <?= $row["title"] ?>
                </td>

                <td class="px-6 py-4 max-w-xs">
                  <p class="truncate-line text-sm text-gray-600" id="desc-<?=$i?>">
                    <?= $row["description"] ?>
                  </p>
                  <button onclick="toggleDescription('desc-<?=$i?>', this)"
                    class="text-xs text-orange-600 hover:underline">see more</button>
                </td>

                <td class="px-6 py-4 text-sm text-gray-600">
                  <?= date("d M Y, h:i A", strtotime($row["created_at"])) ?>
                </td>

                <td class="px-6 py-4">
                  <div class="flex items-center justify-center gap-2">
                    
                    <a href="admin_news_edit?id=<?= $row['id'] ?>"
                      class="w-8 h-8 bg-blue-100 hover:bg-blue-200 text-blue-600 rounded-lg flex justify-center items-center"
                      title="Edit">
                      <i class="fa-solid fa-edit text-sm"></i>
                    </a>

                    <a href="?delete=<?= $row['id'] ?>"
                      onclick="return confirm('Delete this news?');"
                      class="w-8 h-8 bg-red-100 hover:bg-red-200 text-red-600 rounded-lg flex justify-center items-center"
                      title="Delete">
                      <i class="fa-solid fa-trash text-sm"></i>
                    </a>

                  </div>
                </td>
              </tr>
              <?php $i++; } ?>
            </tbody>

          </table>
        </div>

      </div>
    </div>
  </main>

</body>
</html>
